package com.example.MultiVendor;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MultiVendorApplicationTests {

	@Test
	void contextLoads() {
	}

}
